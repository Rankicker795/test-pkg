def ralcat(a,b):
    _str = a+b
    return _str
