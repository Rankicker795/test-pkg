def taco(a,b):
    _str = a + "tacos make me " + b
    return _str
