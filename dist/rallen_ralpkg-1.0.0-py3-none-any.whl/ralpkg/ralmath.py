def raladd(a,b):
    return (a+b)

def ralsub(a,b):
    return (a+b)

